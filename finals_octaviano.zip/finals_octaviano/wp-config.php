<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'finals_octaviano' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'PJ/5t BV$X_K0Jx,qJJpJ1hAFUNM?9>eq!B7vj0EdJ/+Ev]F?>:5j>JZ_ZA%Kc(/' );
define( 'SECURE_AUTH_KEY',  '^I]xB0R`tJ(@,18s5_f?d8W(Khq4 5T{Ko+r|d%;Q{&atPB$kiJkxJfNwv_3v{3O' );
define( 'LOGGED_IN_KEY',    'ZRw1q)1Nv_sh4w,,6QZ(ET*m:_Ke_&eG31Q{c:@&bg%O!UfuEUg~RBjeDvVM6L#_' );
define( 'NONCE_KEY',        'QH<xn1ucj&&u;Khs^gE1&>Ol;OK_!8XF;uk?uPq]?8Vi5Hxi&^jq&2$J.(=b27jL' );
define( 'AUTH_SALT',        'lz.W]xl>v@15t<JGhdUkfxXDIKB^msMn0T@-(duWyDTJ4?oSdO`oU 3IU%=0@8BG' );
define( 'SECURE_AUTH_SALT', 'DSiNmu)@(^*0AcfVQfIXo86h,iDb9TUixJ*cGf.|L,>tok)R7R/2M$M..+:?CqAI' );
define( 'LOGGED_IN_SALT',   'xSLJrBW(rRn#bZ3hEeRlRdY(zt!5D!6ZNKX4`E `.QWreq0=Jnolge;<9,1H-ba+' );
define( 'NONCE_SALT',       '-#n+xy_, yQn*T1`W2kmiD~1baSA3?%.WT?d-gmm[m=mM-PR,WPF=duf+kZ>3+R#' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
